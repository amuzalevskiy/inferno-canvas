import { LinkedEvent } from './../../core/types';
export declare const syntheticEvents: {};
export declare function unmountSyntheticEvent(name: string, dom: any): void;
export declare function handleSyntheticEvent(name: string, lastEvent: Function | LinkedEvent<any, any> | null | false | true, nextEvent: Function | LinkedEvent<any, any> | null | false | true, dom: any): void;
