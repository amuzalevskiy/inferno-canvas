export declare function attachEvent(dom: any, eventName: any, handler: any): void;
