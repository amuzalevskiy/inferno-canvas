export declare function isSameInnerHTML(dom: Element, innerHTML: string): boolean;
