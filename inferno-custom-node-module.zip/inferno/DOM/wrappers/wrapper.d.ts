export declare function createWrappedFunction(methodName: string | string[], applyValue?: Function): Function;
