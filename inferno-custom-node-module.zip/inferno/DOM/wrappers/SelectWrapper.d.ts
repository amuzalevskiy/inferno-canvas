export declare function selectEvents(dom: any): void;
export declare function applyValueSelect(nextPropsOrEmpty: any, dom: any, mounting: boolean, vNode: any): void;
