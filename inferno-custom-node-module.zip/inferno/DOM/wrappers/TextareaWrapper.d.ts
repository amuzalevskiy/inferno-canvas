export declare function textAreaEvents(dom: any, nextPropsOrEmpty: any): void;
export declare function applyValueTextArea(nextPropsOrEmpty: any, dom: any, mounting: boolean): void;
