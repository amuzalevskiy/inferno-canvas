export declare function isCheckedType(type: any): boolean;
export declare function inputEvents(dom: any, nextPropsOrEmpty: any): void;
export declare function applyValueInput(nextPropsOrEmpty: any, dom: any): void;
