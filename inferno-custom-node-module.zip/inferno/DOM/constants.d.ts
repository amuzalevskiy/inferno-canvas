export declare const xlinkNS = "http://www.w3.org/1999/xlink";
export declare const xmlNS = "http://www.w3.org/XML/1998/namespace";
export declare const namespaces: Record<string, string>;
