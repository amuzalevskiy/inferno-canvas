export declare function validateVNodeElementChildren(vNode: any): void;
export declare function validateKeys(vNode: any): void;
export declare function throwIfObjectIsNotVNode(input: any): void;
