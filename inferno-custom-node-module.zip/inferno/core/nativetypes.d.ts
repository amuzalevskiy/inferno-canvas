export declare type NativeClipboardEvent = ClipboardEvent;
export declare type NativeCompositionEvent = CompositionEvent;
export declare type NativeDragEvent = DragEvent;
export declare type NativeFocusEvent = FocusEvent;
